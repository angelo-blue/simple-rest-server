package com.mike.sandpit.blah.json;

public class BlahResponse {
	public String message;
}
